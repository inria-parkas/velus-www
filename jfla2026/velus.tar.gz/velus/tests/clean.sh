#!/usr/bin/env sh

rm -rf \
   *.parsed.lus *.nolast.lus *.noauto.lus *.noswitch.lus *.nolocal.lus \
   *.n.lus *.stc *.obc \
   *.light.c *.s *.exe
