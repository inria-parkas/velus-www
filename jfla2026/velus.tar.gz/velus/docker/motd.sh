#!/bin/bash

echo 
echo "~~~ Welcome to the Velus image. ~~~"
echo
echo "The compiler is [~/velus/velus]."
echo "Some examples are available in [~/velus/examples/]."
echo "Type [cd velus; make -C examples] to compile them."
echo
echo "      ~ Happy hacking! ~"
echo
